(function () {
  'use strict';

  /* ----- Footer year ----- */
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  /* ----- Mobile menu ----- */
  var toggle = document.querySelector('.nav-toggle');
  var menu = document.getElementById('nav-links');
  function setMenu(open) {
    menu.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }
  toggle.addEventListener('click', function () { setMenu(!menu.classList.contains('open')); });
  menu.addEventListener('click', function (e) { if (e.target.tagName === 'A') setMenu(false); });
  document.addEventListener('click', function (e) {
    if (!toggle.contains(e.target) && !menu.contains(e.target)) setMenu(false);
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
  window.addEventListener('resize', function () { if (window.innerWidth > 820) setMenu(false); });

  /* ----- Theme toggle (remembers choice) ----- */
  var root = document.documentElement;
  var themeBtn = document.getElementById('theme-toggle');
  function isDark() {
    var t = root.getAttribute('data-theme');
    if (t) return t === 'dark';
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  }
  function syncThemeLabel() {
    themeBtn.setAttribute('aria-label', isDark() ? 'Switch to light theme' : 'Switch to dark theme');
  }
  syncThemeLabel();
  themeBtn.addEventListener('click', function () {
    var next = isDark() ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('theme', next); } catch (e) {}
    syncThemeLabel();
  });

  /* ----- UltinityBD previous / new switch ----- */
  var ultImg = document.getElementById('ult-img');
  var ultShot = document.getElementById('ult-shot');
  var switchBtns = document.querySelectorAll('.switch-btn');
  switchBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      switchBtns.forEach(function (b) { b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'); });
      ultImg.src = btn.dataset.src;
      ultImg.alt = btn.dataset.alt;
      ultShot.dataset.full = btn.dataset.src;
      ultShot.dataset.alt = btn.dataset.alt;
    });
  });

  /* ----- Lightbox ----- */
  var box = document.getElementById('lightbox');
  var boxImg = document.getElementById('lb-img');
  document.querySelectorAll('.shot').forEach(function (b) {
    b.addEventListener('click', function () {
      boxImg.src = b.dataset.full;
      boxImg.alt = b.dataset.alt || '';
      if (box.showModal) box.showModal(); else window.open(b.dataset.full, '_blank');
    });
  });
  box.querySelector('.lb-close').addEventListener('click', function () { box.close(); });
  box.addEventListener('click', function (e) { if (e.target === box) box.close(); });

  /* ----- Contact form -----
     Uses Formspree (free) when you replace YOUR_FORM_ID in index.html.
     Until then it falls back to opening the visitor's email app. */
  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');
  var TO = 'sayemshazzad55@gmail.com';

  function say(msg, cls) { status.textContent = msg; status.className = 'form-status ' + (cls || ''); }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = form.name.value.trim();
    var email = form.email.value.trim();
    var message = form.message.value.trim();

    if (!name || !email || !message) { say('Please fill in your name, email and message.', 'err'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say('Please enter a valid email address.', 'err'); return; }

    if (form.action.indexOf('YOUR_FORM_ID') !== -1) {
      var subject = encodeURIComponent('Portfolio message from ' + name);
      var body = encodeURIComponent(message + '\n\n' + name + '\n' + email);
      window.location.href = 'mailto:' + TO + '?subject=' + subject + '&body=' + body;
      say('Opening your email app to send the message.', 'ok');
      return;
    }

    say('Sending…');
    fetch(form.action, { method: 'POST', body: new FormData(form), headers: { 'Accept': 'application/json' } })
      .then(function (r) {
        if (r.ok) { form.reset(); say('Message sent. Thank you, I will reply soon.', 'ok'); }
        else { say('Could not send the message. Please use WhatsApp or email instead.', 'err'); }
      })
      .catch(function () { say('Network error. Please use WhatsApp or email instead.', 'err'); });
  });
})();
