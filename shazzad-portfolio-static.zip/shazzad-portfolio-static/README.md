# Shazzad Sayem – Portfolio

Pure static site (HTML, CSS, JavaScript). No PHP, no build step.

## Files
- `index.html` – all content (text, projects, links)
- `style.css` – design (colors are variables at the top)
- `script.js` – menu, dark mode, lightbox, contact form
- `assets/images/` – photo and project screenshots

## Host free on GitHub Pages
1. Create a new repository on GitHub (e.g. `shazzad-portfolio`; or `yourusername.github.io` for a root URL).
2. Upload all files from this folder to the repository root (`index.html` must be at the top level).
3. Repository **Settings → Pages → Build and deployment → Source: Deploy from a branch**, choose `main` and `/ (root)`, then **Save**.
4. After a minute your site is live at `https://yourusername.github.io/repository-name/`.

## Contact form
1. Sign up free at https://formspree.io and create a form to get an ID.
2. In `index.html`, replace `YOUR_FORM_ID` in `action="https://formspree.io/f/YOUR_FORM_ID"`.

Until you do that, the form opens the visitor's email app instead.
