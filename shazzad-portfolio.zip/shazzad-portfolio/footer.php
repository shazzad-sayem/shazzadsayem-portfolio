<footer>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Shazzad Sayem</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
