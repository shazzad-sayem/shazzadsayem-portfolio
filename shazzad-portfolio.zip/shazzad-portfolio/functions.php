<?php
/**
 * Shazzad Portfolio theme functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function shazzad_portfolio_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'shazzad_portfolio_setup' );

function shazzad_portfolio_assets() {
	wp_enqueue_style(
		'shazzad-portfolio-font',
		'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'shazzad-portfolio-style', get_stylesheet_uri(), array( 'shazzad-portfolio-font' ), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'shazzad-portfolio-nav', get_template_directory_uri() . '/assets/js/nav.js', array(), wp_get_theme()->get( 'Version' ), true );
}
add_action( 'wp_enqueue_scripts', 'shazzad_portfolio_assets' );
