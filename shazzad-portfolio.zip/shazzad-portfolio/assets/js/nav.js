(function(){var t=document.querySelector('.nav-toggle'),m=document.getElementById('nav-links');if(!t||!m)return;
function set(o){m.classList.toggle('open',o);t.setAttribute('aria-expanded',o?'true':'false');}
t.addEventListener('click',function(){set(!m.classList.contains('open'));});
m.addEventListener('click',function(e){if(e.target.tagName==='A')set(false);});
document.addEventListener('click',function(e){if(!t.contains(e.target)&&!m.contains(e.target))set(false);});
document.addEventListener('keydown',function(e){if(e.key==='Escape')set(false);});
window.addEventListener('resize',function(){if(window.innerWidth>820)set(false);});})();
