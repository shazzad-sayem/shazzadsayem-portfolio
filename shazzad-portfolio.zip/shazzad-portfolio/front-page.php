<?php
/**
 * Front page template: the one-page portfolio.
 * Edit the text, links and projects below.
 */
get_header();
?>

<header class="hero">
<div>
<h1>Hi, I'm <span>Shazzad Sayem</span>, a web developer.</h1>
<p class="lead">I build high-converting E-commerce stores, custom portfolio websites, and redesign existing websites to make them modern and fast.</p>
<a class="btn" href="#work">See my work</a><a class="btn ghost" href="#contact">Get in touch</a>
</div>
<figure class="photo"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/shazzad-sayem.jpg" alt="Portrait of Shazzad Sayem wearing glasses and a black polo, standing by a railway track at dusk"></figure>
</header>
<section id="about"><h2>About me</h2>
<p class="about">I’m a web developer specializing in building modern e-commerce stores, custom portfolio websites, and redesigning existing web pages. I focus on clean design, fast performance, and user-friendly layouts to help businesses establish a strong online presence and drive conversions.</p></section>
<section id="work"><h2>Project</h2>
<div class="grid">
<div class="card"><h3>Zyres website</h3><img class="thumb" alt="Screenshot of the Zyres website homepage" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/zyres.jpg"><p class="desc">An online store for tech gadgets in Bangladesh, with product listings, categories and a cart.</p><ul class="skills tags"><li>HTML5</li><li>CSS3</li><li>JavaScript</li></ul></div>


<div class="card"><h3>UltinityBD</h3><div style="font-size:.8rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--muted);margin:14px 0 0">Previous version</div><img class="thumb" style="margin-top:6px" alt="Previous version of the UltinityBD website homepage" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ultinitybd-previous.jpg"><div style="font-size:.8rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--muted);margin:14px 0 0">New version</div><img class="thumb" style="margin-top:6px" alt="New version of the UltinityBD website homepage" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/ultinitybd-new.jpg"><p class="desc">An online store for premium model cars in Bangladesh, with a product collection, cart and cash on delivery across the country.</p><ul class="skills tags"><li>HTML5</li><li>CSS3</li><li>JavaScript</li></ul></div>
<div class="card"><h3>AL-BARAQAH</h3><img class="thumb" alt="Screenshot of the AL-BARAQAH website homepage" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/al-baraqah.jpg"><p class="desc">A luxury website for AL-BARAQAH, an alcohol-free White Oud fragrance brand, with a collection, fragrance finder and cart.</p><ul class="skills tags"><li>HTML5</li><li>CSS3</li><li>JavaScript</li></ul></div>
<div class="card"><h3>Brew Buddies</h3><img class="thumb" alt="Screenshot of the Brew Buddies website homepage" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/brew-buddies.jpg"><p class="desc">A fun, friendly website for the Brew Buddies coffee brand, with café locations and a call-to-order option.</p><ul class="skills tags"><li>HTML5</li><li>CSS3</li><li>JavaScript</li></ul></div>
<div class="card"><h3>Century</h3><img class="thumb" alt="Screenshot of the Century restaurant website homepage" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/century.jpg"><p class="desc">A Bangla restaurant website for Century, with popular menu items, location details and a Facebook link.</p><ul class="skills tags"><li>HTML5</li><li>CSS3</li><li>JavaScript</li></ul></div>
</div></section>
<section id="services"><h2>Services</h2>
<div class="grid">
<div class="card"><h3>Professional Website Designer</h3><p class="desc">I design and build modern, responsive websites for businesses and individuals, from online stores to portfolio sites, and I can also redesign your existing website.</p><ul class="skills tags"><li>Web development</li><li>E-commerce websites</li><li>Portfolio websites</li><li>Website redesign</li></ul><div class="actions"><a class="btn" href="https://www.fiverr.com/s/DmmbmVN" target="_blank" rel="noopener">View my gig on Fiverr</a></div></div>
</div></section>
<section id="skills"><h2>Skills</h2>
<ul class="skills"><li>Web development</li><li>E-commerce websites</li><li>Portfolio websites</li><li>Also redesign an existing website</li></ul></section>
<section id="contact"><h2>Let’s Work Together!</h2>
<p class="about">Have a project in mind or a question? Feel free to reach out.</p>
<a class="btn" href="https://wa.me/8801703344127" target="_blank" rel="noopener">💬 Chat on WhatsApp</a>
<a class="btn" href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=sayemshazzad55@gmail.com&amp;su=Hello%20Shazzad" target="_blank" rel="noopener">✉️ Send an Email</a>
<a class="btn" href="https://www.fiverr.com/s/DmmbmVN" target="_blank" rel="noopener">🟢 Hire me on Fiverr</a></section>

<?php get_footer(); ?>
