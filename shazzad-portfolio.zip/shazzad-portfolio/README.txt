Shazzad Portfolio - WordPress theme

INSTALL
1. WordPress dashboard > Appearance > Themes > Add New > Upload Theme.
2. Choose shazzad-portfolio.zip > Install Now > Activate.
3. Settings > Reading > set "Your homepage displays" to "Your latest posts" (or leave as is).
   The portfolio shows on the homepage automatically (front-page.php).

EDIT CONTENT
- Text, projects, services, links: front-page.php
- Colors and layout: style.css (see the :root variables at the top)
- Images: assets/images/ (keep the same file names, or change the names in front-page.php)
- Menu links: header.php
