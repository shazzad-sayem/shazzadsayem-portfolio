<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="wrap">
<nav><b><a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;text-decoration:none">Shazzad Sayem</a></b><button class="nav-toggle" type="button" aria-label="Toggle menu" aria-expanded="false" aria-controls="nav-links"><span></span><span></span><span></span></button><div id="nav-links"><a href="<?php echo esc_url( home_url( '/' ) ); ?>#about">About</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>#work">Project</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>#services">Services</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>#skills">Skills</a><a href="<?php echo esc_url( home_url( '/' ) ); ?>#contact">Contact</a></div></nav>
