<?php
/**
 * Fallback template (blog posts, pages, search, 404).
 */
get_header();
?>
<section>
<?php if ( have_posts() ) : ?>
	<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> style="margin-bottom:40px">
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<div class="about"><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
	<?php the_posts_pagination(); ?>
<?php else : ?>
	<h2>Nothing found</h2>
	<p class="about">Sorry, there is nothing to show here.</p>
<?php endif; ?>
</section>
<?php get_footer(); ?>
